package com.model.Employee;

public class Employee
{
	private int eid;
	private String ename;
	private long emob;
	private String eaddr;
	private double esalary;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public long getEmob() {
		return emob;
	}
	public void setEmob(long emob) {
		this.emob = emob;
	}
	public String getEaddr() {
		return eaddr;
	}
	public void setEaddr(String eaddr) {
		this.eaddr = eaddr;
	}
	public Double getEsalary() {
		return esalary;
	}
	public void setEsalary(double edesg) {
		this.esalary = esalary;
	}

}
