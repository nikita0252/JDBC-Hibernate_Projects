package HqlQueries;

public class Course 
{

}
