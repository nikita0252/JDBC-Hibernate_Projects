package com.dao;

import com.model.Employee;

public interface EmployeeDaoI 
{
	public void createTable(String tablename);
	//public void addData(Employee e);

}
