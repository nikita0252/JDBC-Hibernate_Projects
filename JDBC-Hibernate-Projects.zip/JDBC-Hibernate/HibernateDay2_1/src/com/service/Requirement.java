package com.service;

public interface Requirement 
{
	
	public void insertData();
	public void viewSingleData();
	public void viewAllData();
	public void updateData();
	public void deleteSingleData();
	public void deleteAllData();

}
