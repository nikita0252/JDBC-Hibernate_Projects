package com.client;

import java.util.Scanner;

public class A {

	public static void main(String[] args) {
		
		long mob=1234567890;
		
	}
}
