package com.servicei;

public interface ServiceI {
	public void createTable();

	public void insertData();

	public void updateData();

	public void deleteData();

	public void retriveAllData();

	public void retriveSingleData();

	public void storeprocedure();

}
