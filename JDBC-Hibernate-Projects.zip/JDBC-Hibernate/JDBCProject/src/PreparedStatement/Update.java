package PreparedStatement;
import java.util.Scanner;

public class Update 
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
	}

}
